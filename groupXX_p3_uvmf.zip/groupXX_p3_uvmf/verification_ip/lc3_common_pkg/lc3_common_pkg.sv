//----------------------------------------------------------------------
// lc3_common_pkg
//
// Shared by the LC3 environment packages.
//
// lc3_in_order_scoreboard extends the UVMF in-order scoreboard. Every
// <stage>_out monitor reports one clock after the <stage>_in monitor that
// produced the prediction, so when the run phase ends the last prediction
// (or, for the LC3-level scoreboard, the last couple of delivered
// instructions) has not been observed yet. The UVMF base class would flag
// that as "SCOREBOARD NOT EMPTY". This class accepts up to
// allowed_in_flight leftover predictions, reports them, and still fails
// the test if more than that remain.
//
// lc3_stream_scoreboard checks the instruction stream: every instruction
// the decode stage accepts must be the next one the instruction memory
// delivered. The imem and decode_in monitors can report the same
// instruction on the same clock edge in either order, so the newest
// decoded instruction is held until the next one arrives (or the test
// ends) before it is compared. The LC3 discards the instruction fetched
// in the cycle reset is released, so up to allowed_dropped delivered
// instructions may be skipped without being decoded.
//----------------------------------------------------------------------
package lc3_common_pkg;

  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import uvmf_base_pkg::*;

  class lc3_in_order_scoreboard #(type T = uvmf_transaction_base,
                                  type BASE_T = uvmf_scoreboard_base #(T))
    extends uvmf_in_order_scoreboard #(.T(T), .BASE_T(BASE_T));

    `uvm_component_param_utils( lc3_in_order_scoreboard #(T, BASE_T) )

    int unsigned allowed_in_flight = 3;
    int unsigned in_flight_at_end;

    function new( string name, uvm_component parent );
      super.new( name, parent );
    endfunction : new

    virtual function void check_phase( uvm_phase phase );
      in_flight_at_end = expected_results_q.size();
      if ( in_flight_at_end <= allowed_in_flight ) expected_results_q.delete();
      super.check_phase( phase );
    endfunction : check_phase

    virtual function void report_phase( uvm_phase phase );
      super.report_phase( phase );
      `uvm_info( "SCBD", $sformatf( "%s in flight at end of test: %0d (allowed %0d)",
                                    get_full_name(), in_flight_at_end, allowed_in_flight ), UVM_LOW )
    endfunction : report_phase

  endclass : lc3_in_order_scoreboard

  class lc3_stream_scoreboard #(type T = uvmf_transaction_base,
                                type BASE_T = uvm_scoreboard)
    extends uvmf_scoreboard_base #(.T(T), .BASE_T(BASE_T));

    `uvm_component_param_utils( lc3_stream_scoreboard #(T, BASE_T) )

    T expected_q [$];
    T actual_q   [$];
    int unsigned compare_count;
    int unsigned dropped_count;
    int unsigned allowed_dropped         = 1;
    int unsigned allowed_in_flight       = 3;
    int unsigned max_reported_mismatches = 10;

    function new( string name, uvm_component parent );
      super.new( name, parent );
    endfunction : new

    virtual function void write_expected( T t );
      super.write_expected( t );
      expected_q.push_back( t );
    endfunction : write_expected

    virtual function void write_actual( T t );
      super.write_actual( t );
      actual_q.push_back( t );
      while ( actual_q.size() > 1 ) resolve_oldest();
    endfunction : write_actual

    virtual function void resolve_oldest();
      T actual;
      T expected;
      actual = actual_q.pop_front();
      while ( expected_q.size() > 1 && !expected_q[0].compare( actual ) ) begin
        void'( expected_q.pop_front() );
        dropped_count++;
      end
      compare_count++;
      if ( expected_q.size() != 0 ) begin
        expected = expected_q.pop_front();
        if ( expected.compare( actual ) ) begin
          match_count++;
          `uvm_info( "SCBD", $sformatf( "Instruction %0d : MATCH %s", compare_count, actual.convert2string() ), UVM_HIGH )
          return;
        end
      end
      mismatch_count++;
      if ( mismatch_count <= max_reported_mismatches ) begin
        if ( expected != null )
          `uvm_error( "SCBD", $sformatf( "Instruction %0d : MISMATCH\n  Actual   : %s\n  Expected : %s",
                                         compare_count, actual.convert2string(), expected.convert2string() ) )
        else
          `uvm_error( "SCBD", $sformatf( "Instruction %0d : decoded %s but nothing was delivered",
                                         compare_count, actual.convert2string() ) )
      end
    endfunction : resolve_oldest

    virtual function void check_phase( uvm_phase phase );
      super.check_phase( phase );
      while ( actual_q.size() != 0 ) resolve_oldest();
      if ( dropped_count > allowed_dropped )
        `uvm_error( "SCBD", $sformatf( "%0d delivered instruction(s) were never decoded (allowed %0d)",
                                       dropped_count, allowed_dropped ) )
      if ( end_of_test_empty_check && expected_q.size() > allowed_in_flight )
        `uvm_error( "SCBD", $sformatf( "%0d delivered instruction(s) still undecoded at end of test (allowed %0d)",
                                       expected_q.size(), allowed_in_flight ) )
      if ( compare_count == 0 )
        `uvm_error( "SCBD", "no instructions were compared" )
    endfunction : check_phase

    virtual function void report_phase( uvm_phase phase );
      super.report_phase( phase );
      `uvm_info( "SCBD", $sformatf( "%s delivered:%0d compared:%0d matches:%0d mismatches:%0d never_decoded:%0d in_flight:%0d",
                                    get_full_name(), transaction_count, compare_count, match_count,
                                    mismatch_count, dropped_count, expected_q.size() ), UVM_LOW )
    endfunction : report_phase

  endclass : lc3_stream_scoreboard

endpackage : lc3_common_pkg
