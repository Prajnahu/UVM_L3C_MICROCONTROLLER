//----------------------------------------------------------------------
// Created with uvmf_gen version 2026.1
//----------------------------------------------------------------------
// pragma uvmf custom header begin
// pragma uvmf custom header end
//----------------------------------------------------------------------
//----------------------------------------------------------------------
//     
// DESCRIPTION: This interface performs the control_out signal monitoring.
//      It is accessed by the uvm control_out monitor through a virtual
//      interface handle in the control_out configuration.  It monitors the
//      signals passed in through the port connection named bus of
//      type control_out_if.
//
//     Input signals from the control_out_if are assigned to an internal input
//     signal with a _i suffix.  The _i signal should be used for sampling.
//
//     The input signal connections are as follows:
//       bus.signal -> signal_i 
//
//      Interface functions and tasks used by UVM components:
//             monitor(inout TRANS_T txn);
//                   This task receives the transaction, txn, from the
//                   UVM monitor and then populates variables in txn
//                   from values observed on bus activity.  This task
//                   blocks until an operation on the control_out bus is complete.
//
//----------------------------------------------------------------------
//----------------------------------------------------------------------
//
import uvmf_base_pkg_hdl::*;
import control_out_pkg_hdl::*;
`include "src/control_out_macros.svh"


interface control_out_monitor_bfm 
  ( control_out_if  bus );
  // The pragma below and additional ones in-lined further down are for running this BFM on Veloce
  // pragma attribute control_out_monitor_bfm partition_interface_xif                                  

`ifndef XRTL
// This code is to aid in debugging parameter mismatches between the BFM and its corresponding agent.
// Enable this debug by setting UVM_VERBOSITY to UVM_DEBUG
// Setting UVM_VERBOSITY to UVM_DEBUG causes all BFM's and all agents to display their parameter settings.
// All of the messages from this feature have a UVM messaging id value of "CFG"
// The transcript or run.log can be parsed to ensure BFM parameter settings match its corresponding agents parameter settings.
import uvm_pkg::*;
`include "uvm_macros.svh"
initial begin : bfm_vs_agent_parameter_debug
  `uvm_info("CFG", 
      $psprintf("The BFM at '%m' has the following parameters: ", ),
      UVM_DEBUG)
end
`endif


  // Structure used to pass transaction data from monitor BFM to monitor class in agent.
`control_out_MONITOR_STRUCT
  control_out_monitor_s control_out_monitor_struct;

  // Structure used to pass configuration data from monitor class to monitor BFM.
 `control_out_CONFIGURATION_STRUCT
 

  // Config value to determine if this is an initiator or a responder 
  uvmf_initiator_responder_t initiator_responder;
  // Custom configuration variables.  
  // These are set using the configure function which is called during the UVM connect_phase

  tri clock_i;
  tri reset_i;
  tri  enable_updatePC_i;
  tri  enable_fetch_i;
  tri  enable_decode_i;
  tri  enable_execute_i;
  tri  enable_writeback_i;
  tri  bypass_alu_1_i;
  tri  bypass_alu_2_i;
  tri  bypass_mem_1_i;
  tri  bypass_mem_2_i;
  tri [1:0] mem_state_i;
  tri  br_taken_i;
  assign clock_i = bus.clock;
  assign reset_i = bus.reset;
  assign enable_updatePC_i = bus.enable_updatePC;
  assign enable_fetch_i = bus.enable_fetch;
  assign enable_decode_i = bus.enable_decode;
  assign enable_execute_i = bus.enable_execute;
  assign enable_writeback_i = bus.enable_writeback;
  assign bypass_alu_1_i = bus.bypass_alu_1;
  assign bypass_alu_2_i = bus.bypass_alu_2;
  assign bypass_mem_1_i = bus.bypass_mem_1;
  assign bypass_mem_2_i = bus.bypass_mem_2;
  assign mem_state_i = bus.mem_state;
  assign br_taken_i = bus.br_taken;

  // Proxy handle to UVM monitor
  control_out_pkg::control_out_monitor  proxy;
  // pragma tbx oneway proxy.notify_transaction                 

  // pragma uvmf custom interface_item_additional begin
  // Outputs belong to the inputs sampled one clock earlier. 'pending' marks
  // that the previous falling edge was a valid input cycle; outputs the
  // stage produces combinationally are captured at that same edge.
  bit pending = 1'b0;
  bit hit;
  bit enable_updatePC_c;
  bit enable_fetch_c;
  bit enable_decode_c;
  bit enable_execute_c;
  bit enable_writeback_c;
  bit bypass_alu_1_c;
  bit bypass_alu_2_c;
  bit bypass_mem_1_c;
  bit bypass_mem_2_c;
  bit [1:0] mem_state_c;
  bit br_taken_c;
  // pragma uvmf custom interface_item_additional end
  
  //******************************************************************                         
  task wait_for_reset();// pragma tbx xtf  
    @(posedge clock_i) ;                                                                    
    do_wait_for_reset();                                                                   
  endtask                                                                                   

  // ****************************************************************************              
  task do_wait_for_reset(); 
  // pragma uvmf custom reset_condition begin
    wait ( reset_i === 0 ) ;                                                              
    @(posedge clock_i) ;                                                                    
  // pragma uvmf custom reset_condition end                                                                
  endtask    

  //******************************************************************                         
 
  task wait_for_num_clocks(input int unsigned count); // pragma tbx xtf 
    @(posedge clock_i);  
                                                                   
    repeat (count-1) @(posedge clock_i);                                                    
  endtask      

  //******************************************************************                         
  event go;                                                                                 
  function void start_monitoring();// pragma tbx xtf    
    -> go;
  endfunction                                                                               
  
  // ****************************************************************************              
  initial begin                                                                             
    @go;                                                                                   
    forever begin                                                                        
      @(posedge clock_i);  
      do_monitor( control_out_monitor_struct );
                                                                 
 
      proxy.notify_transaction( control_out_monitor_struct );
 
    end                                                                                    
  end                                                                                       

  //******************************************************************
  // The configure() function is used to pass agent configuration
  // variables to the monitor BFM.  It is called by the monitor within
  // the agent at the beginning of the simulation.  It may be called 
  // during the simulation if agent configuration variables are updated
  // and the monitor BFM needs to be aware of the new configuration 
  // variables.
  //
    function void configure(control_out_configuration_s control_out_configuration_arg); // pragma tbx xtf  
    initiator_responder = control_out_configuration_arg.initiator_responder;
  // pragma uvmf custom configure begin
  // pragma uvmf custom configure end
  endfunction   


  // ****************************************************************************  
            
  task do_monitor(output control_out_monitor_s control_out_monitor_struct);
    //
    // Available struct members:
    //     //    control_out_monitor_struct.enable_updatePC
    //     //    control_out_monitor_struct.enable_fetch
    //     //    control_out_monitor_struct.enable_decode
    //     //    control_out_monitor_struct.enable_execute
    //     //    control_out_monitor_struct.enable_writeback
    //     //    control_out_monitor_struct.bypass_alu_1
    //     //    control_out_monitor_struct.bypass_alu_2
    //     //    control_out_monitor_struct.bypass_mem_1
    //     //    control_out_monitor_struct.bypass_mem_2
    //     //    control_out_monitor_struct.mem_state
    //     //    control_out_monitor_struct.br_taken
    //     //
    // Reference code;
    //    How to wait for signal value
    //      while (control_signal === 1'b1) @(posedge clock_i);
    //    
    //    How to assign a struct member, named xyz, from a signal.   
    //    All available input signals listed.
    //      control_out_monitor_struct.xyz = enable_updatePC_i;  //     
    //      control_out_monitor_struct.xyz = enable_fetch_i;  //     
    //      control_out_monitor_struct.xyz = enable_decode_i;  //     
    //      control_out_monitor_struct.xyz = enable_execute_i;  //     
    //      control_out_monitor_struct.xyz = enable_writeback_i;  //     
    //      control_out_monitor_struct.xyz = bypass_alu_1_i;  //     
    //      control_out_monitor_struct.xyz = bypass_alu_2_i;  //     
    //      control_out_monitor_struct.xyz = bypass_mem_1_i;  //     
    //      control_out_monitor_struct.xyz = bypass_mem_2_i;  //     
    //      control_out_monitor_struct.xyz = mem_state_i;  //    [1:0] 
    //      control_out_monitor_struct.xyz = br_taken_i;  //     
    // pragma uvmf custom do_monitor begin
    forever begin
      @( negedge clock_i );
      if ( reset_i === 1'b1 ) begin
        pending = 1'b0;
      end
      else begin
        hit = pending;
        if ( hit ) begin
          control_out_monitor_struct.enable_updatePC = enable_updatePC_c;
          control_out_monitor_struct.enable_fetch = enable_fetch_c;
          control_out_monitor_struct.enable_decode = enable_decode_c;
          control_out_monitor_struct.enable_execute = enable_execute_c;
          control_out_monitor_struct.enable_writeback = enable_writeback_c;
          control_out_monitor_struct.bypass_alu_1 = bypass_alu_1_c;
          control_out_monitor_struct.bypass_alu_2 = bypass_alu_2_c;
          control_out_monitor_struct.bypass_mem_1 = bypass_mem_1_c;
          control_out_monitor_struct.bypass_mem_2 = bypass_mem_2_c;
          control_out_monitor_struct.mem_state = mem_state_c;
          control_out_monitor_struct.br_taken = br_taken_c;
        end
        pending = 1'b1;
        enable_updatePC_c = enable_updatePC_i;
        enable_fetch_c = enable_fetch_i;
        enable_decode_c = enable_decode_i;
        enable_execute_c = enable_execute_i;
        enable_writeback_c = enable_writeback_i;
        bypass_alu_1_c = bypass_alu_1_i;
        bypass_alu_2_c = bypass_alu_2_i;
        bypass_mem_1_c = bypass_mem_1_i;
        bypass_mem_2_c = bypass_mem_2_i;
        mem_state_c = mem_state_i;
        br_taken_c = br_taken_i;
        if ( hit ) return;
      end
    end
    // pragma uvmf custom do_monitor end
  endtask         
  
 
endinterface

// pragma uvmf custom external begin
// pragma uvmf custom external end

