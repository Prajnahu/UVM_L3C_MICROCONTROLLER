//----------------------------------------------------------------------
// Created with uvmf_gen version 2026.1
//----------------------------------------------------------------------
// pragma uvmf custom header begin
// pragma uvmf custom header end
//----------------------------------------------------------------------
//----------------------------------------------------------------------
//     
// DESCRIPTION: This class can be used to provide stimulus when an interface
//              has been configured to run in a responder mode. It
//              will never finish by default, always going back to the driver
//              and driver BFM for the next transaction with which to respond.
//
//----------------------------------------------------------------------
//----------------------------------------------------------------------
//
class imem_responder_sequence 
  extends imem_sequence_base ;

  `uvm_object_utils( imem_responder_sequence )

  // pragma uvmf custom class_item_additional begin
  // Number of instructions handed to the LC3 so far. The bench sequence
  // waits on this to decide when the test has delivered enough.
  int unsigned responses;
  bit [2:0]    register_number;
  // pragma uvmf custom class_item_additional end

  function new(string name = "imem_responder_sequence");
    super.new(name);
  endfunction

  task body();
    req=imem_transaction::type_id::create("req");
    forever begin
      start_item(req);
      finish_item(req);
      // pragma uvmf custom body begin
      // req now describes the LC3's next fetch; choose the instruction for it.
      // The first 9 clear R0-R7 (R0 twice) with AND Rn,Rn,#0 so every
      // register has a known value; after that, randomize. The factory
      // decides which imem_transaction subclass req is, so each test's
      // constraints apply here.
      responses++;
      if ( responses <= 9 ) begin
        register_number = ( responses <= 2 ) ? 3'd0 : 3'( responses - 2 );
        req.opcode   = OP_AND;
        req.operands = { register_number, register_number, 6'b100000 };
      end
      else if ( !req.randomize() ) begin
        `uvm_error( "IMEM_RESPONDER", "instruction randomize() failed" )
      end
      `uvm_info( "SEQ", $sformatf( "Instruction %0d : %s", responses, req.convert2string() ), UVM_HIGH )
      // pragma uvmf custom body end
    end
  endtask

endclass

// pragma uvmf custom external begin
// pragma uvmf custom external end

