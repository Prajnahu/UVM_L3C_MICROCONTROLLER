//----------------------------------------------------------------------
// Created with uvmf_gen version 2026.1
//----------------------------------------------------------------------
// pragma uvmf custom header begin
// pragma uvmf custom header end
//----------------------------------------------------------------------
//----------------------------------------------------------------------
//     
// DESCRIPTION: This class records imem transaction information using
//       a covergroup named imem_transaction_cg.  An instance of this
//       coverage component is instantiated in the uvmf_parameterized_agent
//       if the has_coverage flag is set.
//
//----------------------------------------------------------------------
//----------------------------------------------------------------------
//
class imem_transaction_coverage  extends uvm_subscriber #(.T(imem_transaction ));

  `uvm_component_utils( imem_transaction_coverage )

  T coverage_trans;

  // pragma uvmf custom class_item_additional begin
  // Instruction-stream coverage: sampled on every instruction delivered to
  // the LC3. Coverpoints marked "weight 0" only feed a cross; they are not
  // counted on their own, so no bin is counted twice.
  typedef enum { MODE_ADD_REG, MODE_ADD_IMM, MODE_AND_REG, MODE_AND_IMM, MODE_NOT, MODE_LD, MODE_ST,
                 MODE_LDI, MODE_STI, MODE_LDR, MODE_STR, MODE_LEA, MODE_BR, MODE_JMP, MODE_OTHER } instr_mode_e;
  typedef enum { PROD_ALU, PROD_LEA, PROD_LOAD, PROD_NONE } prod_e;
  typedef enum { USE_SR1, USE_SR2, USE_BASE, USE_JMP, USE_STORE } use_e;
  typedef enum { MID_OTHER, MID_MEM, MID_CTRL } mid_e;
  typedef enum { SEQ_LOAD_USE_BR, SEQ_ALU_ALU_STORE, SEQ_LDI_USE_BR } seq3_e;

  bit [3:0]    opcode;
  bit [3:0]    prev_opcode;
  bit          have_prev;
  bit [2:0]    dr;
  bit [2:0]    sr1;
  bit [2:0]    sr2;
  bit          mode;
  bit [4:0]    imm5;
  bit [8:0]    offset9;
  bit [5:0]    offset6;
  bit          is_add_and;
  bit          is_pc_relative;
  bit          is_base_offset;
  instr_mode_e instr_mode;
  bit [15:0]   hist [$];     // the two instructions delivered before this one
  int unsigned sampled_count;
  // pragma uvmf custom class_item_additional end

  covergroup instruction_cg;
    // pragma uvmf custom covergroup begin
    option.per_instance = 1;
    // Instruction x addressing mode: register, immediate, PC-relative,
    // indirect, base + offset. JSR, RTI, TRAP and reserved (MODE_OTHER)
    // are an error.
    INSTR_X_MODE : coverpoint instr_mode {
      bins add_register  = { MODE_ADD_REG };
      bins add_immediate = { MODE_ADD_IMM };
      bins and_register  = { MODE_AND_REG };
      bins and_immediate = { MODE_AND_IMM };
      bins not_register  = { MODE_NOT };
      bins ld_pc_relative  = { MODE_LD };
      bins st_pc_relative  = { MODE_ST };
      bins ldi_indirect    = { MODE_LDI };
      bins sti_indirect    = { MODE_STI };
      bins ldr_base_offset = { MODE_LDR };
      bins str_base_offset = { MODE_STR };
      bins lea_pc_relative = { MODE_LEA };
      bins br_pc_relative  = { MODE_BR };
      bins jmp_register    = { MODE_JMP };
      illegal_bins unsupported = { MODE_OTHER };
    }
    // pragma uvmf custom covergroup end
  endgroup

  covergroup sequence_cg;
    option.per_instance = 1;
    PREV : coverpoint prev_opcode {
      option.weight = 0;
      type_option.weight = 0;
      bins op_br = { OP_BR };
      bins op_add = { OP_ADD };
      bins op_ld = { OP_LD };
      bins op_st = { OP_ST };
      bins op_and = { OP_AND };
      bins op_ldr = { OP_LDR };
      bins op_str = { OP_STR };
      bins op_not = { OP_NOT };
      bins op_ldi = { OP_LDI };
      bins op_sti = { OP_STI };
      bins op_jmp = { OP_JMP };
      bins op_lea = { OP_LEA };
    }
    CUR : coverpoint opcode {
      option.weight = 0;
      type_option.weight = 0;
      bins op_br = { OP_BR };
      bins op_add = { OP_ADD };
      bins op_ld = { OP_LD };
      bins op_st = { OP_ST };
      bins op_and = { OP_AND };
      bins op_ldr = { OP_LDR };
      bins op_str = { OP_STR };
      bins op_not = { OP_NOT };
      bins op_ldi = { OP_LDI };
      bins op_sti = { OP_STI };
      bins op_jmp = { OP_JMP };
      bins op_lea = { OP_LEA };
    }
    PREV_X_CUR : cross PREV, CUR;
  endgroup

  covergroup alu_cg;
    option.per_instance = 1;
    ALU_OP : coverpoint opcode {
      option.weight = 0;
      type_option.weight = 0;
      bins op_add = { OP_ADD };
      bins op_and = { OP_AND };
      bins op_not = { OP_NOT };
    }
    ADD_AND_OP : coverpoint opcode iff ( is_add_and ) {
      option.weight = 0;
      type_option.weight = 0;
      bins op_add = { OP_ADD };
      bins op_and = { OP_AND };
    }
    DR  : coverpoint dr  { option.weight = 0; type_option.weight = 0; bins r[] = { [0:7] }; }
    SR1 : coverpoint sr1 { option.weight = 0; type_option.weight = 0; bins r[] = { [0:7] }; }
    SR2 : coverpoint sr2 iff ( is_add_and && !mode ) { option.weight = 0; type_option.weight = 0; bins r[] = { [0:7] }; }
    IMM5 : coverpoint imm5 iff ( is_add_and && mode ) {
      option.weight = 0;
      type_option.weight = 0;
      bins zero = { 0 };
      bins max_pos = { 15 };
      bins min_neg = { 16 };
      bins minus_one = { 31 };
      bins pos = { [1:14] };
      bins neg = { [17:30] };
    }
    OP_X_DR   : cross ALU_OP, DR;
    OP_X_SR1  : cross ALU_OP, SR1;
    OP_X_SR2  : cross ADD_AND_OP, SR2;    // register mode
    OP_X_IMM5 : cross ADD_AND_OP, IMM5;   // immediate mode
  endgroup

  covergroup mem_cg;
    option.per_instance = 1;
    MEM_OP : coverpoint opcode {
      option.weight = 0;
      type_option.weight = 0;
      bins op_ld = { OP_LD };
      bins op_ldi = { OP_LDI };
      bins op_ldr = { OP_LDR };
      bins op_lea = { OP_LEA };
      bins op_st = { OP_ST };
      bins op_sti = { OP_STI };
      bins op_str = { OP_STR };
    }
    PC_OP : coverpoint opcode iff ( is_pc_relative ) {
      option.weight = 0;
      type_option.weight = 0;
      bins op_ld  = { OP_LD };
      bins op_ldi = { OP_LDI };
      bins op_lea = { OP_LEA };
      bins op_st  = { OP_ST };
      bins op_sti = { OP_STI };
    }
    BASE_OP : coverpoint opcode iff ( is_base_offset ) {
      option.weight = 0;
      type_option.weight = 0;
      bins op_ldr = { OP_LDR };
      bins op_str = { OP_STR };
    }
    REG   : coverpoint dr { option.weight = 0; type_option.weight = 0; bins r[] = { [0:7] }; }
    BASER : coverpoint sr1 iff ( is_base_offset ) { option.weight = 0; type_option.weight = 0; bins r[] = { [0:7] }; }
    PCOFFSET9 : coverpoint offset9 iff ( is_pc_relative ) {
      option.weight = 0;
      type_option.weight = 0;
      bins zero = { 0 };
      bins max_pos = { 255 };
      bins min_neg = { 256 };
      bins minus_one = { 511 };
      bins pos = { [1:254] };
      bins neg = { [257:510] };
    }
    OFFSET6 : coverpoint offset6 iff ( is_base_offset ) {
      option.weight = 0;
      type_option.weight = 0;
      bins zero = { 0 };
      bins max_pos = { 31 };
      bins min_neg = { 32 };
      bins minus_one = { 63 };
      bins pos = { [1:30] };
      bins neg = { [33:62] };
    }
    OP_X_REG          : cross MEM_OP, REG;
    PC_OP_X_PCOFFSET9 : cross PC_OP, PCOFFSET9;   // PC-relative and indirect addressing
    BASE_OP_X_OFFSET6 : cross BASE_OP, OFFSET6;   // base + offset addressing
    BASE_OP_X_BASER   : cross BASE_OP, BASER;
  endgroup

  covergroup ctrl_cg;
    option.per_instance = 1;
    BR_OFFSET9 : coverpoint offset9 iff ( opcode == OP_BR ) {
      bins zero = { 0 };
      bins max_pos = { 255 };
      bins min_neg = { 256 };
      bins minus_one = { 511 };
      bins pos = { [1:254] };
      bins neg = { [257:510] };
    }
    JMP_BASER : coverpoint sr1 iff ( opcode == OP_JMP ) { bins r[] = { [0:7] }; }
  endgroup

  // Data dependencies at distance 2 (a register written two instructions
  // earlier and not by the instruction in between). Distance 1 is covered
  // by the bypass coverage sampled from the pipeline.
  covergroup hazard_cg with function sample( prod_e prod, use_e use_kind, mid_e mid );
    option.per_instance = 1;
    PRODUCER : coverpoint prod {
      option.weight = 0;
      type_option.weight = 0;
      bins alu  = { PROD_ALU };
      bins lea  = { PROD_LEA };
      bins load = { PROD_LOAD };
    }
    CONSUMER : coverpoint use_kind {
      option.weight = 0;
      type_option.weight = 0;
      bins sr1        = { USE_SR1 };
      bins sr2        = { USE_SR2 };
      bins base       = { USE_BASE };
      bins jmp_base   = { USE_JMP };
      bins store_data = { USE_STORE };
    }
    BETWEEN : coverpoint mid {
      option.weight = 0;
      type_option.weight = 0;
      bins memory  = { MID_MEM };
      bins control = { MID_CTRL };
    }
    DIST2  : cross PRODUCER, CONSUMER;
    ACROSS : cross PRODUCER, BETWEEN;    // dependency across a memory or control instruction
  endgroup

  covergroup seq3_cg with function sample( seq3_e seq );
    option.per_instance = 1;
    SEQ3 : coverpoint seq {
      bins load_use_br   = { SEQ_LOAD_USE_BR };
      bins alu_alu_store = { SEQ_ALU_ALU_STORE };
      bins ldi_use_br    = { SEQ_LDI_USE_BR };
    }
  endgroup

  function new(string name="", uvm_component parent=null);
    super.new(name,parent);
    instruction_cg = new;
    sequence_cg    = new;
    alu_cg         = new;
    mem_cg         = new;
    ctrl_cg        = new;
    hazard_cg      = new;
    seq3_cg        = new;
  endfunction

  function void build_phase(uvm_phase phase);
    instruction_cg.set_inst_name( "instruction_cg" );
    sequence_cg.set_inst_name   ( "sequence_cg" );
    alu_cg.set_inst_name        ( "alu_cg" );
    mem_cg.set_inst_name        ( "mem_cg" );
    ctrl_cg.set_inst_name       ( "ctrl_cg" );
    hazard_cg.set_inst_name     ( "hazard_cg" );
    seq3_cg.set_inst_name       ( "seq3_cg" );
  endfunction

  // register an instruction writes, or -1
  function int written( bit [15:0] i );
    case ( i[15:12] )
      OP_ADD, OP_AND, OP_NOT, OP_LD, OP_LDR, OP_LDI, OP_LEA : return i[11:9];
      default : return -1;
    endcase
  endfunction

  function prod_e producer( bit [15:0] i );
    case ( i[15:12] )
      OP_ADD, OP_AND, OP_NOT : return PROD_ALU;
      OP_LEA                 : return PROD_LEA;
      OP_LD, OP_LDR, OP_LDI  : return PROD_LOAD;
      default                : return PROD_NONE;
    endcase
  endfunction

  // registers an instruction reads, and how
  function void uses( bit [15:0] i, ref use_e kinds [$], ref int regs [$] );
    kinds.delete();
    regs.delete();
    case ( i[15:12] )
      OP_ADD, OP_AND : begin
        kinds.push_back( USE_SR1 ); regs.push_back( i[8:6] );
        if ( !i[5] ) begin kinds.push_back( USE_SR2 ); regs.push_back( i[2:0] ); end
      end
      OP_NOT       : begin kinds.push_back( USE_SR1 ); regs.push_back( i[8:6] ); end
      OP_LDR       : begin kinds.push_back( USE_BASE ); regs.push_back( i[8:6] ); end
      OP_STR       : begin
        kinds.push_back( USE_BASE ); regs.push_back( i[8:6] );
        kinds.push_back( USE_STORE ); regs.push_back( i[11:9] );
      end
      OP_ST, OP_STI : begin kinds.push_back( USE_STORE ); regs.push_back( i[11:9] ); end
      OP_JMP        : begin kinds.push_back( USE_JMP ); regs.push_back( i[8:6] ); end
      default       : ;
    endcase
  endfunction

  function bit is_alu( bit [15:0] i );
    return i[15:12] inside { OP_ADD, OP_AND, OP_NOT };
  endfunction

  function void sample_hazards( bit [15:0] i );
    bit [15:0] p2, p1;
    int        w2, w1;
    bit        dep1;
    use_e      kinds [$];
    int        regs [$];
    mid_e      mid;
    if ( hist.size() < 2 ) return;
    p2 = hist[0];
    p1 = hist[1];
    w2 = written( p2 );
    w1 = written( p1 );
    case ( p1[15:12] )
      OP_LD, OP_LDR, OP_LDI, OP_ST, OP_STR, OP_STI : mid = MID_MEM;
      OP_BR, OP_JMP                                 : mid = MID_CTRL;
      default                                       : mid = MID_OTHER;
    endcase
    uses( i, kinds, regs );
    foreach ( kinds[k] )
      if ( w2 >= 0 && w2 == regs[k] && w1 != regs[k] ) hazard_cg.sample( producer( p2 ), kinds[k], mid );
    // three-instruction sequences
    uses( p1, kinds, regs );
    dep1 = 1'b0;
    foreach ( regs[k] ) if ( w2 >= 0 && regs[k] == w2 ) dep1 = 1'b1;
    if ( dep1 && i[15:12] == OP_BR && p2[15:12] inside { OP_LD, OP_LDR } ) seq3_cg.sample( SEQ_LOAD_USE_BR );
    if ( dep1 && i[15:12] == OP_BR && p2[15:12] == OP_LDI ) seq3_cg.sample( SEQ_LDI_USE_BR );
    if ( dep1 && i[15:12] inside { OP_ST, OP_STR, OP_STI } && is_alu( p2 ) && is_alu( p1 ) && i[11:9] == w1 )
      seq3_cg.sample( SEQ_ALU_ALU_STORE );
  endfunction

  virtual function void write (T t);
    bit [15:0] instr;
    `uvm_info("COV","Received transaction",UVM_HIGH);
    coverage_trans = t;
    opcode  = t.opcode;
    dr      = t.operands[11:9];
    sr1     = t.operands[8:6];
    sr2     = t.operands[2:0];
    mode    = t.operands[5];
    imm5    = t.operands[4:0];
    offset9 = t.operands[8:0];
    offset6 = t.operands[5:0];
    instr   = { t.opcode, t.operands };
    is_add_and     = ( opcode == OP_ADD ) || ( opcode == OP_AND );
    is_base_offset = ( opcode == OP_LDR ) || ( opcode == OP_STR );
    is_pc_relative = ( opcode == OP_LD ) || ( opcode == OP_LDI ) || ( opcode == OP_LEA )
                  || ( opcode == OP_ST ) || ( opcode == OP_STI );
    case ( opcode )
      OP_ADD  : instr_mode = mode ? MODE_ADD_IMM : MODE_ADD_REG;
      OP_AND  : instr_mode = mode ? MODE_AND_IMM : MODE_AND_REG;
      OP_NOT  : instr_mode = MODE_NOT;
      OP_LD   : instr_mode = MODE_LD;
      OP_ST   : instr_mode = MODE_ST;
      OP_LDI  : instr_mode = MODE_LDI;
      OP_STI  : instr_mode = MODE_STI;
      OP_LDR  : instr_mode = MODE_LDR;
      OP_STR  : instr_mode = MODE_STR;
      OP_LEA  : instr_mode = MODE_LEA;
      OP_BR   : instr_mode = MODE_BR;
      OP_JMP  : instr_mode = MODE_JMP;
      default : instr_mode = MODE_OTHER;
    endcase
    sampled_count++;
    instruction_cg.sample();
    if ( have_prev ) sequence_cg.sample();
    if ( is_add_and || opcode == OP_NOT ) alu_cg.sample();
    else if ( is_pc_relative || is_base_offset ) mem_cg.sample();
    else if ( opcode == OP_BR || opcode == OP_JMP ) ctrl_cg.sample();
    sample_hazards( instr );
    hist.push_back( instr );
    if ( hist.size() > 2 ) void'( hist.pop_front() );
    prev_opcode = opcode;
    have_prev   = 1'b1;
  endfunction

  function real get_total_coverage();
    return ( instruction_cg.get_inst_coverage() + sequence_cg.get_inst_coverage()
           + alu_cg.get_inst_coverage() + mem_cg.get_inst_coverage()
           + ctrl_cg.get_inst_coverage() + hazard_cg.get_inst_coverage()
           + seq3_cg.get_inst_coverage() ) / 7.0;
  endfunction

  virtual function void report_phase(uvm_phase phase);
    `uvm_info( "IMEM_COVERAGE",
               $sformatf( "instructions sampled:%0d  instruction_cg:%0.2f%%  sequence_cg:%0.2f%%  alu_cg:%0.2f%%  mem_cg:%0.2f%%  ctrl_cg:%0.2f%%  hazard_cg:%0.2f%%  seq3_cg:%0.2f%%",
                          sampled_count, instruction_cg.get_inst_coverage(), sequence_cg.get_inst_coverage(),
                          alu_cg.get_inst_coverage(), mem_cg.get_inst_coverage(), ctrl_cg.get_inst_coverage(),
                          hazard_cg.get_inst_coverage(), seq3_cg.get_inst_coverage() ),
               UVM_LOW )
    `uvm_info( "IMEM_COVERAGE", $sformatf( "INSTRUCTION COVERAGE (this test): %0.2f%%", get_total_coverage() ), UVM_LOW )
  endfunction

endclass

// pragma uvmf custom external begin
// pragma uvmf custom external end

